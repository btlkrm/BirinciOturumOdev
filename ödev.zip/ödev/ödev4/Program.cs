﻿using System;

class TahminProgrami
{
    static void Main(string[] args)
    {
        try
        {
            int tahminEdilen = 0;

            Random random = new Random();
            int randomSayi = random.Next(1, 11);

            Console.WriteLine("1 ile 10 arasında bir sayı tahmin et.");



            while (tahminEdilen != randomSayi)
            {

                tahminEdilen = Convert.ToInt32(Console.ReadLine());


                if (tahminEdilen < randomSayi)
                {
                    Console.WriteLine("Daha büyük bir sayı gir.");
                }
                else if (tahminEdilen > randomSayi)
                {
                    Console.WriteLine("Daha küçük bir sayı gir.");
                }
            }

            Console.WriteLine("Tebrikler!!");
        }
        catch (Exception)
        {
            Console.WriteLine("Sadece rakam giriniz.");

        }
    }
}
