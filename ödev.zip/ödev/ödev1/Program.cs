﻿using System;

class Siparis
{
    static void Main(string[] args)
    {
        try
        {
            Console.WriteLine("Sipariş numarasını gir:");


            int siparisNumarasi = Convert.ToInt32(Console.ReadLine());
            switch (siparisNumarasi)
            {
                case 1:
                    Console.WriteLine("Birinci ürün");
                    break;
                case 2:
                    Console.WriteLine("İkinci ürün");
                    break;
                case 3:
                    Console.WriteLine("Üçüncü ürün");
                    break;
                default:
                    Console.WriteLine("Farklı bir sipariş numarasıyla deneyin...");
                    break;
            }
        }
        catch (Exception)
        {
            Console.WriteLine("Sipariş numarası sadece rakamlardan oluşmaktadır.Lütfen farklı bir sipariş numarasıyla yeniden deneyiniz.");
        }
    }
}
