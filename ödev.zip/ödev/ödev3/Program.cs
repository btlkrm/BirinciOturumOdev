﻿// Do-While ve While döngüleri, bir kod bloğunu bir koşul sağlanana kadar veya sağlanmadığı sürece tekrarlamak için kullanılan programlama yapılarıdır.
//While döngüsü, belirtilen koşul doğru olduğu sürece kod bloğunu tekrarlar. Bu döngüde, koşul başlangıçta doğru değilse, döngü hiçbir zaman çalışmayabilir.
//Do-While döngüsü, kod bloğunu en az bir kez çalıştırır ve ardından koşul doğru olduğu sürece tekrarlar. Bu nedenle, koşulun başlangıçta doğru olup olmaması önemli değildir.


using System;

class Program
{
    static void Main(string[] args)
    {
        //while dongusu
        //int i = 5;

        // while (i > 0)
        // {

        //     Console.WriteLine(i);

        //     i--;

        // }



        //do-while dongusu

        int i = 5;

        do
        {

            Console.WriteLine(i);
            i++;

        } while (i < 10);

        Console.ReadLine();
    }
}

