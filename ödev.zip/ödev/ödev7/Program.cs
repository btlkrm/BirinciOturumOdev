﻿using System;
using System.ComponentModel.Design;

class NotHesaplayanProgram
{
    static void Main(string[] args)
    {
        try
        {
            Console.Write("Öğrenci sayısını gir: ");
            int ogrenciSayisi = Convert.ToInt32(Console.ReadLine());

            if (ogrenciSayisi > 0)
            {
                for (int i = 1; i <= ogrenciSayisi; i++)
                {
                    Console.WriteLine($"--- {i}. Öğrenci ---");
                    Console.Write("Öğrenci adı: ");
                    string? ad = Console.ReadLine();

                    Console.Write("Öğrenci soyadı: ");
                    string? soyad = Console.ReadLine();

                    Console.Write("1. Sınav notu: ");
                    int not1 = Convert.ToInt32(Console.ReadLine());

                    Console.Write("2. Sınav notu: ");
                    int not2 = Convert.ToInt32(Console.ReadLine());

                    Console.Write("3. Sınav notu: ");
                    int not3 = Convert.ToInt32(Console.ReadLine());


                    double ortalama = (not1 + not2 + not3) / 3.0;

                    Console.WriteLine("" + ad + " " + soyad + " " + $"Not ortalaması: {ortalama:F2}\n");
                }

            }
            else
            {
                Console.Write("Not ortalaması hesaplanacak bir öğrenci bulunmamaktadır.");

            }
        }
        catch (Exception)
        {
            Console.Write("Sadece rakam giriniz.");

        }
    }
}

