﻿using System;

class MukemmelSayiProgram
{
  

    static void Main(string[] args)
    {
        try
        {
            Console.Write("Bir sayı girin: ");
            int sayi = Convert.ToInt32(Console.ReadLine());

          if(sayi>0)
            {
                if (MukemmelSayiControl(sayi))
                {
                    Console.WriteLine(sayi + " mükemmel sayıdır.");
                }
                else
                {
                    Console.WriteLine(sayi + " mükemmel sayı değildir.");
                }
            }
          else { Console.WriteLine("0 dan büyük rakam giriniz."); }
        }
        catch (Exception)
        {
            Console.WriteLine("Sadece rakam giriniz.");
        }
    }


    static bool MukemmelSayiControl(int sayi)
    {
        int toplam = 0;
        for (int i = 1; i < sayi; i++)
        {
            if (sayi % i == 0)
            {
                toplam += i;
            }
        }
        return toplam == sayi;
    }
}
