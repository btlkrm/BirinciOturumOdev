﻿using System;

class AlisverisTutarHesaplama
{
    static void Main(string[] args)
    {
        try
        {
            Console.WriteLine("Kaç ürün almak istiyorsunuz?");
            int urunSayisi = Convert.ToInt32(Console.ReadLine());
             if(urunSayisi > 0 )
            {
                double toplamTutar = 0;

                for (int i = 1; i <= urunSayisi; i++)
                {
                    Console.WriteLine("Ürün " + i + " fiyatı:");
                    double urunFiyati = Convert.ToDouble(Console.ReadLine());
                    toplamTutar += urunFiyati;
                }

                Console.WriteLine("Toplam tutar: " + toplamTutar);
            }

             else { Console.WriteLine("Lütfen sıfırdan büyük bir sayı giriniz."); }
        }
        catch(Exception e)
        {
            Console.WriteLine(e.ToString());
        }
    }
}