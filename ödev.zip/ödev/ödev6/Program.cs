﻿/*
 Length:Bir string'in karakter sayısını döndürür.
 ToUpper: Bir string'in tüm karakterlerini büyük harfe dönüştürür.
 ToLower: Bir string'in tüm karakterlerini küçük harfe dönüştürür.
 Substring: Belirtilen başlangıç dizininden başlayarak bir string'in belirli bir alt dizesini alır.
 Concat: İki veya daha fazla string'i birleştirir.
 IndexOf: Bir alt dizeyi belirtilen bir başlangıç dizininden itibaren bulur.
 Replace: Belirtilen bir alt dizeyi başka bir alt dizeyle değiştirir.
 Split: Bir string'i belirli bir ayırıcı karaktere göre böler ve alt dizelerin bir dizisini döndürür.
Trim: Bir string'in başındaki ve sonundaki boşlukları kaldırır.
 */

using System;

class Program
{


    static void Main(string[] args)
    {
        string str = " Merhaba ";
        int length = str.Length;
        Console.WriteLine(length);

    
        string upperCase = str.ToUpper(); 
        Console.WriteLine(upperCase);

        string lowerCase = str.ToLower(); 
        Console.WriteLine(lowerCase);

        string subStr = str.Substring(2);
        Console.WriteLine(subStr);

        string combined = string.Concat(str, " ", str);
        Console.WriteLine(combined);

        int index = str.IndexOf("aba"); 
        Console.WriteLine(index);

        string replaced = str.Replace("Merhaba", "Betül");
        Console.WriteLine(replaced);


        string str1 = "mavi,sarı,kırmızı";
        string[] renk = str1.Split(',');
    
        foreach (var rnk in renk)
        {
            Console.WriteLine($"{rnk}");
        }

        string trimmed = str.Trim();
        Console.WriteLine(trimmed);

    }


}